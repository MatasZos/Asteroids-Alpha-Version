using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public GameObject asteroidPrefab;
    public float spawnRate = 2f; // Time interval between asteroid spawns
    public Transform[] spawnPoints;
    public int score = 0; // Players score
    public bool isGameOver = false;
    public Text scoreText; 
    public Text gameOverText; 
    private int missedAsteroids = 0; // Total missed asteroids

    void Start()
    {
        gameOverText.gameObject.SetActive(false);

        // Start spawning asteroids
        InvokeRepeating("SpawnAsteroid", 0f, spawnRate);
    }

    // Spawn an asteroid at a random position
    void SpawnAsteroid()
    {
        if (isGameOver) return; // Prevent spawning if the game is over

        float randomX = Random.Range(-8f, 8f); 
        Vector3 spawnPosition = new Vector3(randomX, 6f, 0);
        
        Instantiate(asteroidPrefab, spawnPosition, Quaternion.identity);
    }
    public void GameOver()
    {
        isGameOver = true; 

        // Game over message and the game ending
        gameOverText.gameObject.SetActive(true);
        CancelInvoke("SpawnAsteroid");
        Debug.Log("Game Over! Final Score: " + score);
    }
    public void AddScore(int points)
    {
        score += points;
        scoreText.text = "Score: " + score; // Updates the score each time a asteroid is destroyed
    }

    // Increment missed asteroid count
    public void IncrementMissedAsteroids()
    {
        missedAsteroids++;
        if (missedAsteroids >= 10) // If 10 asteroids are missed, end the game
        {
            GameOver();
        }
    }
}
