using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public float moveSpeed = 3f; // Speed of the asteroid's downward movement
    public int pointsForDestruction = 10; // Points for destroying the asteroid
    private GameController gameController; // Reference to GameController to trigger game over

    void Start()
    {
        gameController = FindObjectOfType<GameController>();
    }

    void Update()
    {
        // Makes the asteroid fall
        transform.Translate(Vector3.down * moveSpeed * Time.deltaTime);

        // Destroy the asteroid if it goes off screen
        if (transform.position.y < -6f)
        {
            // Increment the missed asteroid counter
            gameController.IncrementMissedAsteroids();
            Destroy(gameObject); // Destroy the asteroid
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // If the asteroid collides with the player, trigger Game Over
        if (other.CompareTag("Player"))
        {
            gameController.GameOver();  // Trigger game over in GameController
            Destroy(other.gameObject);  // Destroy the player
            Destroy(gameObject);        // Destroy the asteroid
        }

        // If the asteroid collides with a projectile, destroy both
        if (other.CompareTag("Projectile"))
        {
            gameController.AddScore(pointsForDestruction); // Add score for destroying asteroid
            Destroy(gameObject); // Destroy the asteroid
            Destroy(other.gameObject); // Destroy the projectile
        }
    }
}
