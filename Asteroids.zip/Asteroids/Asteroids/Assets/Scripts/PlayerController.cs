using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f; 
    public GameObject projectilePrefab;
    public Transform firePoint; 
    public float fireRate = 0.5f; 
    private float nextFireTime = 0f; 

    void Update()
    {
        // Control the player
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(horizontalInput, verticalInput, 0) * moveSpeed * Time.deltaTime;
        transform.Translate(movement);

        // Fire projectiles
        if (Input.GetKey(KeyCode.Space) && Time.time >= nextFireTime)
        {
            FireProjectile();
            nextFireTime = Time.time + fireRate; // Fire rate
        }
    }

    void FireProjectile()
    {
        Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);
    }
}
